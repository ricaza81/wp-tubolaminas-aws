<?php

namespace Never5\DownloadMonitor\Dependencies\PayPal\Api;

use Never5\DownloadMonitor\Dependencies\PayPal\Common\PayPalModel;

/**
 * Class BillingAgreementToken
 *
 * PayPal generated billing agreement token. It is a token returned by /v1/billing-agreements/agreement-token API end point.
 *
 * @package Never5\DownloadMonitor\Dependencies\PayPal\Api
 *
 */
class BillingAgreementToken extends PayPalModel
{
}
